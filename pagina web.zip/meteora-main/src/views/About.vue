<template>
  <section class="section container mx-auto g-4 px-3 my-4 mb-xl-5 row">
    <h2 class="col-12 col-xl-6 text-center section-title">
      Welcome to
      <img
        src="@/assets/images/logo/logo_black.png"
        alt="Meteora"
        class="meteora d-block mx-auto w-100"
      />
    </h2>
    <div class="col-12 col-xl-6">
      <p>
        ...our timeless, casual, and no-gender clothing e-commerce store! We believe that
        <b>fashion</b>
        goes beyond fleeting trends. It
        <b>is an expression of individuality, personal style, and self-confidence.</b>
      </p>
      <p>
        At our store, we offer a carefully curated collection of versatile pieces that transcend
        time and stereotypes. Our goal is to provide clothing that adapts effortlessly to any style
        and occasion, empowering you to
        <b>embrace your uniqueness and celebrate your own sense of fashion.</b>
      </p>
      <p>
        Whether you're looking for a classic wardrobe staple or a statement piece that defies
        conventional norms, we have something for everyone. Our timeless collection includes
        comfortable and stylish garments that are designed to
        <b>fit all body types and preferences.</b>
      </p>
      <p>
        <b
          >We value diversity and inclusivity, recognizing that fashion has no boundaries or
          limitations.</b
        >
        Our clothing is created with a no-gender approach, allowing individuals to express
        themselves freely and authentically. We believe that everyone should have the freedom to
        wear what makes them feel confident and comfortable.
      </p>
      <p>
        As an e-commerce store,
        <b>we strive to provide a seamless and enjoyable shopping experience.</b>
        Browse our carefully curated selection, discover new possibilities, and find pieces that
        resonate with your personal style. Our commitment to quality ensures that our garments are
        made to last, allowing you to build a wardrobe that stands the test of time.
      </p>
      <p>
        <b
          >Join us in embracing fashion as a means of self-expression, breaking free from passing
          trends, and creating your own unique style.</b
        >
        We invite you to explore our collection and embark on a journey of timeless fashion that
        transcends boundaries.
      </p>
    </div>
  </section>
</template>

<script setup lang="ts"></script>

<style lang="scss" scoped>
@use '../assets/styles/variables' as v;

.meteora {
  max-width: 26.25rem;
}
</style>
