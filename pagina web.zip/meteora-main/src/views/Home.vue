<template>
  <Carousel />
  <CategoryCard />
  <ProductsCards />
</template>

<script setup lang="ts">
import Carousel from '@/components/CarouselVue.vue';
import CategoryCard from '@/components/CategoryCard.vue';
import ProductsCards from '@/components/ProductsCards.vue';
</script>
