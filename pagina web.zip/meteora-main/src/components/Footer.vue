<template>
  <footer class="text-center bg-black text-bg-dark">
    <p class="card-text py-3">
      2023 &#169; Design by
      <a href="https://www.alura.com.br/" target="_blank" class="primary-yellow">Alura</a>
      |<br class="d-md-none" />
      Built by
      <a href="https://github.com/sucodelarangela" target="_blank" class="primary-yellow"
        >sucodelarangela</a
      >
      |<br class="d-md-none" />
      Fictitious non-commercial project.
    </p>
  </footer>
</template>

<style lang="scss" scoped>
a {
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
}
</style>
