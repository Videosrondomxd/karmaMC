export default interface IFilters {
  formatCategory: (category: string) => string;
}
